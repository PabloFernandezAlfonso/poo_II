package prueba;

import java.lang.reflect.Array;
import java.util.concurrent.ForkJoinPool;

public class Main{
/*
	Doctor d1 = new Doctor("Pablo", (short)2001, "nada");
	Doctor d2 = new Doctor("Juan", (short)1999, "nada");
	Doctor d3 = new Doctor("Carlos", (short)1990, "cardiología");
	
	Ingeniero i1 = new Ingeniero("Pablo", (short)2001, "nada");
	Ingeniero i2 = new Ingeniero("Juan", (short)1999, "nada");
	Ingeniero i3 = new Ingeniero("Carlos", (short)1990, "civil");
	
	Profesor p1 = new Profesor("Pablo", (short)2001, "nada");
	Profesor p2 = new Profesor("Juan", (short)1999, "nada");
	Profesor p3 = new Profesor("Carlos", (short)1990, "ciencias del arte");
*/	
	Profesion[] lista = {
			new Doctor("Pablo", (short)2001, "nada"),
			new Doctor("Juan", (short)1999, "nada"),
			new Doctor("Carlos", (short)1990, "cardiología"),
			new Ingeniero("Alejandro", (short)2002, "nada"),
			new Ingeniero("Mario", (short)1995, "nada"),
			new Ingeniero("Luigi", (short)1993, "civil"),
			new Profesor("Pablo", (short)2000, "nada"),
			new Profesor("Pablo", (short)19994, "nada"),
			new Profesor("Pablo", (short)1980, "ciencias del arte")
	};
	
	for(int i = 0; i < lista.length; i++) {
		
	}
	

}
